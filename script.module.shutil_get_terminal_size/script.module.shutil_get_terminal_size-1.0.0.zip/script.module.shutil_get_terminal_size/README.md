script.module.shutil_get_terminal_size
======================================

shutil.which library repacked for Kodi

Based on Backport Python 3 shutil_get_terminal_size

- https://docs.python.org/3/library/shutil.html#shutil.get_terminal_size
- https://github.com/chrippa/backports.shutil_get_terminal_size
